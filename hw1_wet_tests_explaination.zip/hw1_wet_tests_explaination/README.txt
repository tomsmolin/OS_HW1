Your code was tested using 20 tests + 2 bonus tests. Each test weighs 5 points, which means that you can get a grade up to 110.

Your feedback files include the following:
- Your submitted code and the smash executable we built on our VM.
- tests directory that contains:
	- testX.out files: the output of running testX using your smash code
	- testX.out.processed files: a processed file of testX.out that filters jobs lifetime in jobs command, and filters PIDs and replaces each of them with a serial number to make the test output system independent.
- grade.csv: this file contains the results of running all tests using your smash code. A value of 1 means that your test was passed, other values (mainly, 0) means that your test was failed. The test result is produced by running the test against your code, saving your smash output to testX.out file, processing the testX.out file and saving the processed/filtered output file in testX.out.processed, and then comparing it (the processed/filtered output file) with testX.exp.processed, which are available in current directory (the same directory of this README).
- We are not going to publish the tests input files, you got only the expected output to allow you compare your smash output with our expected output.

Tests list:
===========
Here are the tests list that we ran against your code (all other test names in your grade.csv file can be ignored):
test_bg1
test_bg5
test_cat1
test_cat3
test_cd1
test_cd3
test_external1
test_fg2
test_fg3
test_jobs1
test_jobs2
test_jobs4
test_kill1
test_kill5
test_pipe2
test_pipe4
test_pwd1
test_redirection1
test_redirection3
test_showpid
test_timeout1
test_timeout2

Appeals:
========
- If you got zero or did not get a grade, it's usually due to missing submission or code that did not compile (could be due to a faulty makefile or an incorrect zip file structure).
- We give you an option to resubmit your code with only minor modifications to the code or code structure. 
  Submissions that received a grade above 90 are not eligible for this option.
  Using this option requires you to:
  	- Do your code modifications (please note that only minor modifications will be accepted)
  	- Write a short letter (test or PDF file) that explains your code modifications
  	- Test your modified code before resubmitting it because this will be no additional opportunities to resubmit your code.
